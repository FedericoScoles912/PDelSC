const stripHtml = (html) => html.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();

const countWords = (html) => {
    const text = stripHtml(html);
    return text ? text.split(' ').length : 0;
};

const estimateReadingTime = (html, wordsPerMinute = 220) => {
    const words = countWords(html);
    return Math.max(1, Math.ceil(words / wordsPerMinute));
};

const buildSiteMetrics = (articleEntries) => {
    const totalArticles = articleEntries.length;
    const totalWords = articleEntries.reduce((sum, article) => sum + countWords(article.content), 0);
    const averageWords = totalArticles ? Math.round(totalWords / totalArticles) : 0;

    return {
        totalArticles,
        totalWords,
        averageWords
    };
};

module.exports = {
    countWords,
    estimateReadingTime,
    buildSiteMetrics
};
